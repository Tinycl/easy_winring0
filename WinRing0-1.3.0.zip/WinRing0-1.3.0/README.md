# WinRing0
Windows Ring0 Access

###File Directory

>dll
* driver source

>drv
* driver normal interface

##Description
Allow user application to access ring0 level resource

* access cpu msr register
* read/write memory directly
* io pci device
* etc...
